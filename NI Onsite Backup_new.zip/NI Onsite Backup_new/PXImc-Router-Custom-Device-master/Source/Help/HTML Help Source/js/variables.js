//Used by FeedbackLink.js
var L_submitFeedbackBlurb = "Submit feedback on this topic";
//LOCALIZATION: This isn't currently used in localized help, but when it is it will need to be localized in all languages.

var L_helpType = "STD_ENG";
//Used by Stylesheet.js also; LOCALIZATION: this should be localized in all languages


//Used by DynamicJumps.js
var L_table_title_string = "In This Topic";
//LOCALIZATION: localize in all languages; refers to other concepts in this html file.
var L_top_text = "Top";//LOCALIZATION: localize in all languages' refers to the top of the


var L_sndvibasstchm = "sndvibasst.chm";
var L_expresswbchm = "expresswb.chm";
//Used by SignalExpress and SVA CHMs to link to each other using javascript (necessary for multi-lingual products that ship all languages in one installer)

//Used by expandable_tree.js
var L_VIServerClassHierarchy = "VI Server Class Hierarchy";
var L_LVStyleChecklist = "LabVIEW Style Checklist";
var L_BuildingAppsChecklist = "Building Applications Checklist";
var L_GuidelinesForUsingMathScript = "Guidelines for Using LabVIEW MathScript in Real-Time Applications (MathScript RT Module)";
var L_SupportForMathScript = "Support for MathScript Functions in Real-Time Applications (MathScript RT Module)";
var L_SystemExplorerWindow = "System Explorer Window";