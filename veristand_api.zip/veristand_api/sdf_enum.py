

"""
Package cfl.veristand_control.sdf_enum is used for the enums of Veristand

Relative Title:
    cfl.veristand_control.sdf_enum.py
"""

from enum import Enum

class Target(Enum):
    """
    Enumerations for the Target
    4 Connecting, 3 Disabled, 0 Disconnected, 2 Idle, 1 Running
    """
    Disconnected = 0
    Running = 1
    Idle = 2
    Disabled = 3
    Connecting = 4

class System(Enum):
    """
    Enumerations for the System
    0 Idle, 1 Active
    """
    Idle = 0
    Active = 1
    Disconnected = 2

if __name__ == '__main__':

    #print(System.Idle.value == 0)
    print(System.Idle)
    print(repr(System(str(0))) == System.Idle)
    print(System.Active)
    #print(Target(2))
    #print(Target(3).name)
    # try:
    #     print(Target(7))
    # except ValueError as e:
    #     print(e)


