
"""
Package cfl.veristand_control.sdf_generation is used to generate Veristand system definition files

Relative Title:
    cfl.veristand_control.sdf_generation.py
"""

import sys
import os
#import Pyro4

# Add VeriStand path to system path
try:
    sys.path.append("c:\\Program Files (x86)\\National Instruments\\VeriStand 2016\\nivs.lib\\Reference Assemblies")
except Exception:
    raise RuntimeError("NI VeriStand Path Not Found!!!")
try:
    import clr
except Exception:
    raise RuntimeError("Python for .NET library not found!!!")

clr.AddReference("NationalInstruments.VeriStand")
clr.AddReference("NationalInstruments.VeriStand.SystemDefinitionAPI")
clr.AddReference("System")

from NationalInstruments.VeriStand import Error
from NationalInstruments.VeriStand.SystemDefinitionAPI import SystemDefinition
from NationalInstruments.VeriStand.SystemDefinitionAPI import Target
from System import String
from System import Array

# Only a single instance will be created for Pyro
#@Pyro4.behavior(instance_mode="single")
class SystemDefinitionFile(object):

    Target_Types = ("Windows", "Pharlap")

    def __init__(self):
        """
        Constructor for the system definition file generation
        """
        self._session = "idle"
        self.name = ""
        self.description = ""
        self.file_name = ""
        self.path = ""
        self.system_definition = None
        self.target = None
        self.target_list = {}
        self.custom_device_list = {}
        self.targets = None
        self.root = None
        self.alias = None

    def clear_session(self):
        self._session = "idle"

    def get_status(self):
        return self._session, self.name

    def _get_target_info(self, name=""):
        """
        Gets SDF branch information

        :param name: Target Location
        :type name: str
        """
        # Gets the root
        self.root = self.system_definition.Root
        # Gets the targets List
        self.targets = self.root.GetTargets()
        # Gets the target list
        for target in self.targets.GetTargetList():
            self.target_list[target.Name] = target
        # Gets the specified target, the default is the first location
        try:
            self.target = self.target_list[name]
        except KeyError:
            self.target = None

    def create(self, name="", description="", platform="Windows", file_path="", ip="", target_rate="100",
               controller="Controller"):
        """
        Allows for the creation of a system definition file

        :param name: System definition file name
        :type name: str
        :param description: System definition file description
        :type description: str
        :param platform: System definition file platform
        :type platform: str
        :param file_path: System definition file location
        :type file_path: str
        :param ip: IP address for the system to deploy to
        :type ip: str
        :param target_rate: Refresh rate of the target deployed to
        :type target_rate: str
        :param controller: Controller Name
        :type controller: str
        """
        self._session = "busy"
        self.name = name
        self.description = description
        self.file_name = name+".nivssdf"
        self.path = os.path.join(file_path, self.file_name)
        self.system_definition = SystemDefinition(self.name, self.description, "Northrop Grumman", "1.0.0.0",
                                                  controller, platform, self.path)
        self._get_target_info(controller)
        self.target.TargetRate = target_rate
        if platform is not "Windows" and ip:
            self.target.IPAddress = ip
        self._save()

    def get_aliases(self):
        """
        Gets signal alias information from the system definition file
        """
        aliases = {}
        self.alias = self.root.GetAliases()
        alias_data = self.alias.GetAliasesList()
        for alias in alias_data:
            try:
                aliases[alias.Name] = alias.LinkedChannel.NodePath
            except AttributeError:
                aliases[alias.Name] = None
        return aliases

    def add_alias(self, name="", description="", path=""):
        """
        Adds an alias to the system definition file

        :param name: Alias Name
        :type name: str
        :param description: Alias Description
        :type description: str
        :param path: Aliased path
        :type path: str
        """
        self.alias = self.root.GetAliases()
        self.alias.DeleteUnmappedAliases()
        self._save()
        status = self.alias.AddNewAliasByPath(name, description, path)
        if not status:
            raise RuntimeError("Failed to add an alias or alias may already exist")
        aliases = self.get_aliases()
        if aliases[name] is None:
            self.alias.DeleteUnmappedAliases()
            self._save()
            raise RuntimeError("Alias path is incorrect, alias not added")
        self._save()

    def clear_mapping(self):
        """
        Clears all defined system mappings
        """
        self.root.ClearChannelMappings()
        self._save()

    def enable_target(self, name=""):
        self._get_target_info(name)
        try:
            self.target.DisableTarget = False
        except AttributeError:
            raise RuntimeError("Cannot enable undefined controller!!")
        else:
            self._save()

    def disable_target(self, name=""):
        self._get_target_info(name)
        try:
            self.target.DisableTarget = True
        except AttributeError:
            raise RuntimeError("Cannot disable undefined controller!!")
        else:
            self._save()

    def add_target(self, name="", platform="Windows", ip="", target_rate="100"):
        """
        Adds a target to the targets List

        :param name: Target name
        :type name: str
        :param platform: Target Type
        :type platform: str
        :param ip: Target IP address
        :type ip: str
        :param target_rate: Target Rate
        :type target_rate: str
        """
        # See if a controller with this name already exists
        self._get_target_info(name)
        if self.target is not None:
            raise RuntimeError("Target already exists!!!")
        # Verify the user enters a support platform
        if platform not in self.Target_Types:
            raise RuntimeError("Invalid Platform Type")
        # Add a target
        target_error = Error()
        target_instance = Target(name, platform)
        target_instance.TargetRate = target_rate
        if platform is not "Windows" and ip:
            target_instance.IPAddress = ip
        status = self.targets.AddTarget(target_instance, target_error)
        target_instance.Finalize()
        if not status[0]:
            raise RuntimeError(status[1].Message)
        self._save()
        self._get_target_info(name)
        if name != self.target.Name:
            raise RuntimeError("Target not added!!!")

    def add_mapping(self, source="", destination=""):
        """
        Add to the system mapping

        :param source: Mapping source
        :type source: str
        :param destination: Mapping destination
        :type destination: str
        """
        mapping_error = Error()
        # Get defined aliases
        aliases = self.get_aliases()
        # Allows for mapping of Alias names and total paths
        try:
            src = Array[String]([String(aliases[source])])
        except KeyError:
            src = Array[String]([String(source)])
        try:
            dst = Array[String]([String(aliases[destination])])
        except KeyError:
            dst = Array[String]([String(destination)])
        status = self.root.AddChannelMappings(src, dst, mapping_error)
        if not status[0]:
            raise RuntimeError(status[1].Message)
        self._save()

    def get_mapping(self):
        """
        Gets the system mapping
        """
        src = Array.CreateInstance(String, 0)
        dst = Array.CreateInstance(String, 0)
        mapping_data = self.root.GetChannelMappings(src, dst)
        source_data = mapping_data[1]
        destination_data = mapping_data[2]
        mapping = zip(source_data, destination_data)
        return mapping

    def open(self, name="", file_path=""):
        """
        Opens a system definition file

        :param name: System definition file name
        :type name: str
        :param file_path: System definition file location
        :type file_path: str
        """
        self._session = "busy"
        self.name = name
        self.file_name = name+".nivssdf"
        self.path = os.path.join(file_path, self.file_name)
        self.system_definition = SystemDefinition(self.path)
        self._get_target_info()

    def _save(self):
        """
        Saves a system definition file
        """
        if self.system_definition is not None:
            error = String("System Definition Failed to Save!!")
            status = self.system_definition.SaveSystemDefinitionFile(error)
            if not status[0]:
                raise RuntimeError(error)

    def _get_custom_device(self, target_name="", custom_device_name=""):
        """
        Gets a custom device from a target

        :param target_name: Target Name
        :type target_name: str
        :param custom_device_name: Custom Device Name
        :type custom_device_name: str
        """
        self._get_target_info(target_name)
        self.custom_device_list = {}
        if self.target is not None:
            custom_devices = self.target.GetCustomDevices()
            # Gets the custom device list
            for custom_device in custom_devices.GetCustomDeviceList():
                self.custom_device_list[custom_device.Name] = custom_device
        # Gets the specified custom device
        try:
            return self.custom_device_list[custom_device_name]
        except KeyError:
            return None

    def update_all_custom_device_channel_data(self, target_name="", custom_device_name="", value=0):
        """
        Updates all custom device channels with specified value

        :param target_name: Target Name
        :type target_name: str
        :param custom_device_name: Custom Device Name
        :type custom_device_name: str
        :param value: Channel Default Value
        :type value: int
        """
        custom_device = self._get_custom_device(target_name, custom_device_name)
        channel_list = {}
        if custom_device is not None:
            for channel in custom_device.GetCustomDeviceChannelList():
                if isinstance(value, int):
                    channel.DefaultValue = value
                    channel_list[channel.Name] = channel
                    SDF._save()
                else:
                    raise RuntimeError("Channel value must of type int!!")

    def update_custom_device_channel_data(self, target_name="", custom_device_name="", channel_name="", value=0):
        """
        Updates a specified custom device channel

        :param target_name: Target Name
        :type target_name: str
        :param custom_device_name: Custom Device Name
        :type custom_device_name: str
        :param channel_name: Custom Channel Name
        :type channel_name: str
        :param value: Channel Default Value
        :type value: int
        """
        custom_device = self._get_custom_device(target_name, custom_device_name)
        channel_list = {}
        if custom_device is not None:
            for channel in custom_device.GetCustomDeviceChannelList():
                channel_list[channel.Name] = channel
            try:
                channel = channel_list[channel_name]
            except KeyError:
                raise RuntimeError("Custom Device {0} Channel {1} Not Found!!".format(custom_device_name, channel_name))
            else:
                if isinstance(value, int):
                    channel.DefaultValue = value
                    SDF._save()
                else:
                    raise RuntimeError("Channel value must of type int!!")

    def close(self):
        """
        Closes a system definition file
        """
        if self.system_definition is not None:
            self.system_definition.Finalize()
            self._session = "idle"
            self.name = ""
            self.description = ""
            self.file_name = ""
            self.path = ""
            self.system_definition = None
            self.target = None
            self.target_list = {}
            self.targets = None
            self.root = None
            self.alias = None


if __name__ == '__main__':
    # # Windows Test
    # SDF = SystemDefinitionFile()
    # SDF.create(name="real_Test_new_windows",
    #                            description="System Definition created with the System Definition Offline API",
    #                            platform="Windows", file_path="C:\\Users\\Administrator\\Desktop\\")
    # try:
    #     SDF.add_alias("Absolute_Time", "Time of the system", "Targets/Controller/System Channels/Absolute Time")
    # except RuntimeError as e:
    #     print(e)
    # print(SDF.name)
    # print(SDF.target.TargetRate)
    # print(SDF.target.IPAddress)
    # SDF.close()
    #
    # # Pharlap Test
    # SDF = SystemDefinitionFile()
    # SDF.create(name="real_Test_new_pharlap",
    #                            description="System Definition created with the System Definition Offline API",
    #                            platform="Pharlap", file_path="C:\\Users\\Administrator\\Desktop\\", ip="128.12.6.13",
    #                            target_rate="1000")
    # print(SDF.name)
    # print(SDF.target.TargetRate)
    # print(SDF.target.IPAddress)
    # SDF.close()
    #
    # # Pharlap Open test
    # SDF = SystemDefinitionFile()
    # SDF.open(name="real_Test_new_pharlap", file_path="C:\\Users\\Administrator\\Desktop\\")
    # try:
    #     SDF.add_alias("bob", "some STUFF crap", "path\\crap")
    # except RuntimeError as e:
    #     print(e)
    # SDF.add_alias("larry", "other crap", "Targets/Controller/System Channels/DAQ Error")
    # print(SDF.get_mapping())
    # print(SDF.get_aliases())
    # print(SDF.name)
    # SDF.close()

    # # Windows Open test
    # SDF = SystemDefinitionFile()
    # SDF.open(name="real_Test_new_windows", file_path="C:\\Users\\Administrator\\Desktop\\")
    # try:
    #     SDF.add_alias("bob", "some STUFF crap", "path\\crap")
    # except RuntimeError as e:
    #     print(e)
    # SDF.add_target(name="Johnny", target_rate="1000")
    # try:
    #     SDF.add_target(name="Johnny", target_rate="1000")
    # except RuntimeError as e:
    #     print(e)
    # try:
    #     SDF.disable_target(name="Bob")
    # except RuntimeError as e:
    #     print(e)
    # try:
    #     SDF.enable_target(name="Bob")
    # except RuntimeError as e:
    #     print(e)
    # SDF.disable_target(name="Johnny")
    # SDF.enable_target(name="Controller")
    # print(SDF.target.TargetRate)
    # print(SDF.target.IPAddress)
    # SDF.clear_mapping()
    # print(SDF.get_mapping())
    # SDF.add_mapping(source="Targets/Controller/System Channels/DAQ Error", destination="Targets/Controller/System Channels/System Command")
    # SDF.add_alias("Loop_Rate", "Time of the system", "Targets/Controller/System Channels/Actual Loop Rate")
    # print(SDF.get_aliases())
    # SDF.add_mapping(source="Loop_Rate", destination="Targets/Controller/System Channels/DAQ Error")
    # print(SDF.get_mapping())
    # SDF.add_mapping(source="Aliases/Absolute_Time", destination="Targets/Controller/System Channels/Command Index")
    # print(SDF.get_mapping())
    # print(SDF.name)
    # SDF.close()

    # Tests done at Intech
    SDF = SystemDefinitionFile()
    SDF.open(name="test1",
             file_path="C:\\Users\\Public\\Documents\\National Instruments\\NI VeriStand 2016\\Projects\\test1")
    # Any value greater than 0 is considered true
    SDF.update_all_custom_device_channel_data(target_name="chassis1", custom_device_name="PXI3Slot5", value=13)
    SDF.update_custom_device_channel_data(target_name="chassis1", custom_device_name="PXI3Slot5",
                                          channel_name="Relay 88", value=88)
    SDF.close()

