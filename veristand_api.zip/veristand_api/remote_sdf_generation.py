"""
Package cfl.veristand_control.remote_sdf_generation is used to control Veristand remotely

Relative Title:
    cfl.veristand_control.remote_sdf_generation.py
"""

import Pyro4
from Pyro4 import errors
import yaml
import subprocess

# Set the max retires of for pyro 10 times before raising the exception
Pyro4.config.MAX_RETRIES = 10

class RemoteSystemDefinitionFile(object):

    # Gets the host information
    sdf_config = yaml.safe_load(open("sdf_config.yml"))['host']
    hostname = sdf_config['hostname']
    port = sdf_config['port']
    ip = sdf_config['ip']
    sdf_actions = {}

    def __init__(self):
        """
        Constructor for the system definition file generation
        """
        self.name = ""
        self._sdfgenerator = None
        try:
            ns_ping = subprocess.Popen(['python', '-m', 'Pyro4.nsc', '-v', 'ping'],
                                       stdout=subprocess.PIPE).communicate()[0].split('\n')[1]
        except IndexError:
            raise RuntimeError("Name Server Not Running")
        if "Failed" in ns_ping:
            raise RuntimeError("Name Server Not Running")
        resolveduri = Pyro4.resolve("PYRO:Pyro.NameServer@"+self.hostname+":"+self.port)
        with Pyro4.locateNS(host=resolveduri.host, port=resolveduri.port) as ns:
            for sdf_action, sdf_uri in ns.list(prefix="sdf.").items():
                self.sdf_actions[sdf_action] = Pyro4.Proxy(sdf_uri)
        if not self.sdf_actions:
            raise RuntimeError("Remote SDF control server not running")
        self._sdfgenerator = self.sdf_actions["sdf.generator"]
        self.status = self._sdfgenerator.get_status()
        if self.status[0] == "busy":
            self._sdfgenerator = None
            raise RuntimeError("Remote SDF generation session busy")

    def remote_create(self, name="", description="", platform="Windows", file_path="", ip="", target_rate="100"):
        """
        Allows for the creation of a system definition file

        :param name: System definition file name
        :type name: str
        :param description: System definition file description
        :type description: str
        :param platform: System definition file platform
        :type platform: str
        :param file_path: System definition file location
        :type file_path: str
        :param ip: IP address for the system to deploy to
        :type ip: str
        :param target_rate: Refresh rate of the target deployed to
        :type target_rate: str
        """
        self.name = name
        self._sdfgenerator.create(name=self.name, description=description, platform=platform, file_path=file_path,
                                  ip=ip, target_rate=target_rate)
        self.status = self._sdfgenerator.get_status()
        if self.status[0] == "busy" and self.name != self.status[1]:
            self._sdfgenerator = None
            raise RuntimeError("Remote SDF generation session busy")

    def remote_add_target(self, name="", platform="Windows", ip="", target_rate="100"):
        """
        Adds a target to the targets List

        :param name: Target name
        :type name: str
        :param platform: Target Type
        :type platform: str
        :param ip: Target IP address
        :type ip: str
        :param target_rate: Target Rate
        :type target_rate: str
        """
        if self._sdfgenerator is not None:
            self._sdfgenerator.add_target(name=name, platform=platform, ip=ip, target_rate=target_rate)

    def remote_get_aliases(self):
        """
        Gets signal alias information from the system definition file
        """
        if self._sdfgenerator is not None:
            return self._sdfgenerator.get_aliases()

    def remote_add_alias(self, name="", description="", path=""):
        """
        Adds an alias to the system definition file

        :param name: Alias Name
        :type name: str
        :param description: Alias Description
        :type description: str
        :param path: Aliased path
        :type path: str
        """
        if self._sdfgenerator is not None:
            self._sdfgenerator.add_alias(name=name, description=description, path=path)

    def remote_clear_mapping(self):
        """
        Clears all defined system mappings
        """
        if self._sdfgenerator is not None:
            self._sdfgenerator.clear_mapping()

    def remote_enable_target(self, name=""):
        """
        Enables defined target

        :param name: Target name
        :type name: str
        """
        if self._sdfgenerator is not None:
            self._sdfgenerator.enable_target(name=name)

    def remote_disable_target(self, name=""):
        """
        Disables defined target

        :param name: Target name
        :type name: str
        """
        if self._sdfgenerator is not None:
            self._sdfgenerator.disable_target(name=name)

    def remote_add_mapping(self, source="", destination=""):
        """
        Add to the system mapping

        :param source: Mapping source
        :type source: str
        :param destination: Mapping destination
        :type destination: str
        """
        if self._sdfgenerator is not None:
            self._sdfgenerator.add_mapping(source=source, destination=destination)

    def remote_get_mapping(self):
        """
        Gets the system mapping
        """
        if self._sdfgenerator is not None:
            return self._sdfgenerator.get_mapping()

    def remote_open(self, name="", file_path=""):
        """
        Opens a system definition file

        :param name: System definition file name
        :type name: str
        :param file_path: System definition file location
        :type file_path: str
        """
        self.name = name
        self._sdfgenerator.open(name=self.name, file_path=file_path)
        self.status = self._sdfgenerator.get_status()
        if self.status[0] == "busy" and self.name != self.status[1]:
            self._sdfgenerator = None
            raise RuntimeError("Remote SDF generation session busy")

    @classmethod
    def clear_busy_session(cls):
        """
        Use this method if a session was not closed correctly and the
        remote connection is hung up.
        """
        try:
            resolveduri = Pyro4.resolve("PYRO:Pyro.NameServer@"+cls.hostname+":"+cls.port)
            with Pyro4.locateNS(host=resolveduri.host, port=resolveduri.port) as ns:
                for sdf_action, sdf_uri in ns.list(prefix="sdf.").items():
                    cls.sdf_actions[sdf_action] = Pyro4.Proxy(sdf_uri)
            if not cls.sdf_actions:
                raise RuntimeError("Remote SDF control server not running")
            cls.sdf_actions["sdf.generator"].clear_session()
            cls.sdf_actions["sdf.generator"].close()
            cls.sdf_actions["sdf.generator"]._pyroRelease()
        except errors.NamingError:
            raise RuntimeError("Name Server Not Running!!")

    def remote_close(self):
        """
        Closes a system definition file
        """
        if self._sdfgenerator is not None:
            self._sdfgenerator.close()
            self._sdfgenerator._pyroRelease()


if __name__ == '__main__':

    # Generates SDF files to the desktop

    # For testing purposes
    try:
        RemoteSystemDefinitionFile.clear_busy_session()
    except Exception as e:
        print(e)

    # Windows Test
    sdfgenerator = RemoteSystemDefinitionFile()

    sdfgenerator.remote_create(name="real_Test_new_windows",
                        description="System Definition created with the System Definition Offline API",
                        platform="Windows", file_path="C:\\Users\\J73670\\Desktop\\")
    try:
        sdfgenerator2 = RemoteSystemDefinitionFile()
        sdfgenerator2.remote_create(name="real_Test_new_windows",
                            description="System Definition created with the System Definition Offline API",
                            platform="Windows", file_path="C:\\Users\\J73670\\Desktop\\")
    except RuntimeError as e:
        print(e)
    try:
        sdfgenerator.remote_add_alias("Absolute_Time", "Time of the system", "Targets/Controller/System Channels/Absolute Time")
    except RuntimeError as e:
        print(e)
    sdfgenerator.remote_close()

    # Pharlap Test
    sdfgenerator.remote_create(name="real_Test_new_pharlap",
                        description="System Definition created with the System Definition Offline API",
                        platform="Pharlap", file_path="C:\\Users\\J73670\\Desktop\\", ip="128.12.6.13",
                        target_rate="1000")
    sdfgenerator.remote_close()

    # Pharlap Open test
    sdfgenerator.remote_open(name="real_Test_new_pharlap", file_path="C:\\Users\\J73670\\Desktop\\")
    try:
        sdfgenerator.remote_add_alias("bob", "some STUFF crap", "path\\crap")
    except RuntimeError as e:
        print(e)
    sdfgenerator.remote_add_alias("larry", "other crap", "Targets/Controller/System Channels/DAQ Error")
    print(sdfgenerator.remote_get_mapping())
    print(sdfgenerator.remote_get_aliases())
    sdfgenerator.remote_close()

    # Windows Open test
    sdfgenerator.remote_open(name="real_Test_new_windows", file_path="C:\\Users\\J73670\\Desktop\\")
    try:
        sdfgenerator.remote_add_alias("bob", "some STUFF crap", "path\\crap")
    except RuntimeError as e:
        print(e)
    sdfgenerator.remote_add_target(name="Johnny", target_rate="1000")
    try:
        sdfgenerator.remote_add_target(name="Johnny", target_rate="1000")
    except RuntimeError as e:
        print(e)
    try:
        sdfgenerator.remote_enable_target(name="Bob")
    except RuntimeError as e:
        print(e)
    sdfgenerator.remote_disable_target(name="Johnny")
    sdfgenerator.remote_enable_target(name="Controller")
    sdfgenerator.remote_clear_mapping()
    print(sdfgenerator.remote_get_mapping())
    sdfgenerator.remote_add_mapping(source="Targets/Controller/System Channels/DAQ Error",
                             destination="Targets/Controller/System Channels/System Command")
    sdfgenerator.remote_add_alias("Loop_Rate", "Time of the system", "Targets/Controller/System Channels/Actual Loop Rate")
    print(sdfgenerator.remote_get_aliases())
    sdfgenerator.remote_add_mapping(source="Loop_Rate", destination="Targets/Controller/System Channels/DAQ Error")
    print(sdfgenerator.remote_get_mapping())
    sdfgenerator.remote_add_mapping(source="Aliases/Absolute_Time", destination="Targets/Controller/System Channels/Command Index")
    print(sdfgenerator.remote_get_mapping())
    sdfgenerator.remote_close()

