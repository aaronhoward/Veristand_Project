import sys
# Add VeriStand path to system path
try:
    sys.path.append("c:\\Program Files (x86)\\National Instruments\\VeriStand 2017\\nivs.lib\\Reference Assemblies")
except Exception:
    raise RuntimeError("NI VeriStand Path Not Found!!!")
try:
    import clr
except Exception:
    raise RuntimeError("Python for .NET library not found!!!")

clr.AddReference("NationalInstruments.VeriStand")
clr.AddReference("NationalInstruments.VeriStand.ClientAPI")
clr.AddReference("NationalInstruments.VeriStand.DataTypes")
clr.AddReference("NationalInstruments.VeriStand.RealTimeSequenceDefinitionApi")
clr.AddReference("NationalInstruments.VeriStand.SystemDefinitionAPI")
clr.AddReference("System")

