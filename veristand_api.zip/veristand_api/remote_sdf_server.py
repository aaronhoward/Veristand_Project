"""
Package cfl.veristand_control.remote_sdf_server is used to control Veristand remotely

Relative Title:
    cfl.veristand_control.remote_sdf_server.py
"""
import socket
import threading
import subprocess
import Pyro4
import Pyro4.naming
import Pyro4.socketutil
import Pyro4.core
from sdf_deploy import SystemDefinitionDeploy
from sdf_generation import SystemDefinitionFile

# Gets the host name
hostname = socket.gethostname()
# Gets the local IP
this_ip = Pyro4.socketutil.getIpAddress(None, workaround127=True)
# Exposes the SDF Generator
SDF_GENERATOR = Pyro4.expose(SystemDefinitionFile)
# Exposes the SDF Deploy
SDF_DEPLOY = Pyro4.expose(SystemDefinitionDeploy)
# Resets the pyro's configurations
Pyro4.config.reset(useenvironment=False)
# Compress data sent across the server.
Pyro4.config.COMPRESSION = True
# Allow pyro to return extended configurationc
Pyro4.config.DETAILED_TRACEBACK = True
# Don't allow the os bind multiple servers to this socket
Pyro4.config.SOCK_REUSE = False
# Sets the server type to multiplex so remote command occur in order.
Pyro4.config.SERVERTYPE = "multiplex"
# Sets the multiplexing poll timeout
Pyro4.config.POLLTIMEOUT = 10
# Sets the serializer
Pyro4.config.SERIALIZER = "serpent"
# Host name the name server will bind on
Pyro4.config.HOST = hostname
# The IP address of the name servers broadcast responder
Pyro4.config.NS_BCHOST = hostname
# The IP address of the name server
Pyro4.config.NS_HOST = hostname
# Prevents server from hanging
Pyro4.config.COMMTIMEOUT = 1.0

# Name Server
name_server = "PYRO:Pyro.NameServer@"+hostname+":9090"

# See if the name server is already running
# NSC = name server control tool
ns_info = subprocess.Popen(['python', '-m', 'Pyro4.nsc', '-v', 'list'],
                           stdout=subprocess.PIPE).communicate()[0].split('\n')
current_ns = ns_info[1].split(": ")[1]

print("Starting Name Server "+name_server)
# See if the name server is already running
if current_ns != name_server:
    # Start a Pyro name server and daemon server process
    ns_thread = threading.Thread(target=Pyro4.naming.startNSloop, kwargs={'host': hostname, 'enableBroadcast': True,
                                                                          'bchost': hostname, 'port': 9090})
    ns_thread.daemon = True
    ns_thread.start()

    with Pyro4.Daemon(host=this_ip, port=0) as daemon:
        deploy_uri = daemon.register(SDF_DEPLOY, objectId="sdf_deploy", force=False)
        gen_uri = daemon.register(SDF_GENERATOR, objectId="sdf_generator", force=False)
        resolveduri = Pyro4.resolve("PYRO:Pyro.NameServer@"+hostname+":9090")
        with Pyro4.locateNS(host=resolveduri.host, port=resolveduri.port) as ns:
            ns.register("sdf.deploy", deploy_uri)
            ns.register("sdf.generator", gen_uri)
        daemon.requestLoop()
else:
    print("SDF Server Already Running!!")

