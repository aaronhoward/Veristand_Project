"""
Package cfl.veristand_control.remote_sdf_deploy is used to control Veristand remotely

Relative Title:
    cfl.veristand_control.remote_sdf_deploy.py
"""
import Pyro4
from Pyro4 import errors
import yaml
import subprocess
import os

# Set the max retires of for pyro 10 times before raising the exception
Pyro4.config.MAX_RETRIES = 10


class RemoteSystemDefinitionDeploy(object):

    # Gets the host information
    sdf_config = yaml.safe_load(open("sdf_config.yml"))['host']
    hostname = sdf_config['hostname']
    port = sdf_config['port']
    ip = sdf_config['ip']
    sdf_actions = {}

    def __init__(self):
        """
        Constructor for the system definition file generation
        """
        self.name = ""
        self._sdfdeploy = None
        try:
            ns_ping = subprocess.Popen(['python', '-m', 'Pyro4.nsc', '-v', 'ping'],
                                       stdout=subprocess.PIPE).communicate()[0].split('\n')[1]
        except IndexError:
            raise RuntimeError("Name Server Not Running")
        # Raise a runtime error if no name servers are running on the network
        if "Failed" in ns_ping:
            raise RuntimeError("Name Server Not Running")
        # Resolving the URI allows for multiple name servers to be running on the network
        resolveduri = Pyro4.resolve("PYRO:Pyro.NameServer@"+self.hostname+":"+self.port)
        with Pyro4.locateNS(host=resolveduri.host, port=resolveduri.port) as ns:
            for sdf_action, sdf_uri in ns.list(prefix="sdf.").items():
                self.sdf_actions[sdf_action] = Pyro4.Proxy(sdf_uri)
        # If no sdf actions have been registered the name server is not running
        if not self.sdf_actions:
            raise RuntimeError("Remote SDF control server not running")
        self._sdfdeploy = self.sdf_actions["sdf.deploy"]
        self.status = self._sdfdeploy.status()
        # If the status is Active a session is already running
        if self.status[0] == "Active":
            self._sdfdeploy = None
            raise RuntimeError("Remote SDF deploy session busy")

    def remote_launch_veristand(self):
        """
        Veristand Gateway errors may be due to the software not running, this allows for the
        software to remotely be opened.
        """
        if self._sdfdeploy is not None:
            self._sdfdeploy.launchveristand()

    def remote_connect(self, name="", file_path="", ip="localhost"):
        """
        Connect and deploy to the Veristand gateway

        :param name: System definition file name
        :type name: str
        :param file_path: System definition file location
        :type file_path: str
        :param ip: IP address for the system to deploy to
        :type ip: str
        """
        self.name = name
        self.status = self._sdfdeploy.status()
        location = os.path.join(file_path, self.name)
        location += ".nivssdf"
        if (self.status[0] == "Active") and (location != self.status[2]):
            self._sdfdeploy = None
            raise RuntimeError("Remote SDF deploy session busy")
        else:
            self._sdfdeploy.connect(name=self.name, file_path=file_path, ip=ip)

    def remote_status(self):
        """
        Get Gateway status to see what state it's in
        """
        if self._sdfdeploy is not None:
            return self._sdfdeploy.status()

    def remote_read_channel(self, alias_name=""):
        """
        Read the data of a defined Alias

        :param alias_name: Aliases name to read
        :type alias_name: str
        """
        if self._sdfdeploy is not None:
            return self._sdfdeploy.read_channel(alias_name=alias_name)

    @classmethod
    def clear_busy_session(cls):
        """
        Use this method if a session was not closed correctly and the
        remote connection is hung up.
        """
        try:
            resolveduri = Pyro4.resolve("PYRO:Pyro.NameServer@"+cls.hostname+":"+cls.port)
            with Pyro4.locateNS(host=resolveduri.host, port=resolveduri.port) as ns:
                for sdf_action, sdf_uri in ns.list(prefix="sdf.").items():
                    cls.sdf_actions[sdf_action] = Pyro4.Proxy(sdf_uri)
            if not cls.sdf_actions:
                raise RuntimeError("Remote SDF control server not running")
            cls.sdf_actions["sdf.deploy"].disconnect()
            cls.sdf_actions["sdf.deploy"]._pyroRelease()
        except errors.NamingError:
            raise RuntimeError("Name Server Not Running!!")

    def remote_disconnect(self):
        """
        Disconnect and un-deploy from the Veristand gateway
        """
        if self._sdfdeploy is not None:
            self._sdfdeploy.disconnect()
            self.status = self._sdfdeploy.status()
            self._sdfdeploy._pyroRelease()


if __name__ == '__main__':
    import time

    # For testing purposes
    try:
        RemoteSystemDefinitionDeploy.clear_busy_session()
    except Exception as e:
        print(e)

    # Deploys the SDF file for localhost windows

    sdfdeploy = RemoteSystemDefinitionDeploy()

    sdfdeploy2 = RemoteSystemDefinitionDeploy()

    print(sdfdeploy.remote_status())
    try:
        sdfdeploy.remote_connect(name="real_Test_new_windows2", file_path="C:\\Users\\J73670\\Desktop\\")
    except RuntimeError as e:
        print(e)
        print(sdfdeploy.remote_status())

    try:
        sdfdeploy2.remote_connect(name="real_Test_new_windows", file_path="C:\\Users\\J73670\\Desktop\\")
    except RuntimeError as e:
        print(e)
        print(sdfdeploy2.remote_status())


    print(sdfdeploy.remote_status())
    try:
        sdfdeploy.remote_connect(name="real_Test_new_windows2", file_path="C:\\Users\\J73670\\Desktop\\")
    except RuntimeError as e:
        print(e)
        print(sdfdeploy.remote_status())
    time.sleep(2)
    print(sdfdeploy.remote_read_channel("Loop_Rate"))
    print(sdfdeploy.remote_read_channel("Absolute_Time"))
    time.sleep(2)
    print(sdfdeploy.remote_read_channel("Loop_Rate"))
    print(sdfdeploy.remote_read_channel("Absolute_Time"))
    time.sleep(2)
    try:
        print(sdfdeploy.remote_read_channel("Steaviethetv"))
    except RuntimeError as e:
        print(e)
    time.sleep(2)
    print(sdfdeploy.remote_read_channel("Loop_Rate"))
    print(sdfdeploy.remote_read_channel("Absolute_Time"))
    print(sdfdeploy.remote_status())
    time.sleep(10)
    try:
        sdfdeploy.remote_disconnect()
    except RuntimeError as e:
        print(e)
    try:
        sdfdeploy.remote_disconnect()
    except RuntimeError as e:
        print(e)
    print(sdfdeploy.remote_status())
