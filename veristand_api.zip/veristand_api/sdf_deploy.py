

"""
Package cfl.veristand_control.sdf_deploy is used to generate Veristand system definition files

Relative Title:
    cfl.veristand_control.sdf_deploy.py
"""

import sys
import os
import subprocess
#import Pyro4

# Add VeriStand path to system path
try:
    # Adds the path to the DLL's
    sys.path.append("c:\\Program Files (x86)\\National Instruments\\VeriStand 2016\\nivs.lib\\Reference Assemblies")
except Exception:
    raise RuntimeError("NI VeriStand Path Not Found!!!")
try:
    import clr
except Exception:
    raise RuntimeError("Python for .NET library not found!!!")

clr.AddReference("NationalInstruments.VeriStand")
clr.AddReference("NationalInstruments.VeriStand.ClientAPI")
clr.AddReference("System")

from NationalInstruments.VeriStand.ClientAPI import Factory
from NationalInstruments.VeriStand.ClientAPI import SystemState
from NationalInstruments.VeriStand.ClientAPI import TargetState
from System import String
from System import Array
from System import UInt32
from System import Double
from sdf_enum import Target
from sdf_enum import System

# Only a single instance will be created for Pyro
#@Pyro4.behavior(instance_mode="single")
class SystemDefinitionDeploy(object):

    def __init__(self):
        """
        Creates the setup for a system definition file deployment

        Note: TCP ports 2035 and 2036 need to be open for proper communications
        """
        self.name = ''
        self.ip = ''
        self.file_name = ''
        self.path = ''
        self.factory_worker = None
        # 0 Idle, 1 Actice
        self.system_status_state = System.Idle
        self.system_status_targets = []
        self.system_status_sdf_location = ""
        # 4 Connecting, 3 Disabled, 0 Disconnected, 2 Idle, 1 Running
        self.target_status_state = {}

    def launch_veristand(self):
        try:
            subprocess.Popen([r"c:\Program Files (x86)\National Instruments\VeriStand 2017\NI VeriStand.exe"])
        except WindowsError:
            raise RuntimeError("Veristand executable not found")

    def _createfactoryworker(self):
        """
        Creates the factory worker allowing for communications with the Veristand gateway
        """
        factory = Factory()
        try:
            self.factory_worker = factory.GetIWorkspace2(self.ip)
        except Exception:
            raise RuntimeError("The Veristand Gateway is not running, please ensure Veristand is running")

    def _getsystemstate(self):
        """
        Get the Status of the connected system

        0 Idle, 1 Active
        """
        system_targets = []
        state = SystemState.Idle
        sdf_info = String("")
        targets = Array[String]([String("")])
        status = self.factory_worker.GetSystemState(state, sdf_info, targets)
        if status[0].IsError:
            raise RuntimeError(status[0].ResolvedErrorMessage)
        for target in status[3]:
            self._gettargetstate(target)
            system_targets.append(target)
        self.system_status_state = status[1]
        self.system_status_sdf_location = status[2]
        self.system_status_targets = system_targets

    def _gettargetstate(self, target):
        """
        Gets the target status

        4 Connecting, 3 Disabled, 0 Disconnected, 2 Idle, 1 Running
        """
        state = TargetState.Idle
        status = self.factory_worker.GetTargetState(target, state)
        if status[0].IsError:
            raise RuntimeError(status[0].ResolvedErrorMessage)
        self.target_status_state[target] = Target(status[1]).name

    def connect(self, name="", file_path="", ip="localhost"):
        """
        Connect and deploy to the Veristand gateway

        :param name: System definition file name
        :type name: str
        :param file_path: System definition file location
        :type file_path: str
        :param ip: IP address for the system to deploy to
        :type ip: str
        """
        self._createfactoryworker()
        timeout = UInt32(60000)
        if self.factory_worker is not None:
            self._getsystemstate()
            # If the system is already active don't deploy because an active session is already running
            # Only deploy if the system is idle
            print(self.system_status_state)
            if self.system_status_state == System.Idle:
                self.name = name
                self.ip = ip
                self.file_name = name+".nivssdf"
                self.path = os.path.join(file_path, self.file_name)
                status = self.factory_worker.ConnectToSystem(self.path, True, timeout)
                if status.IsError:
                    raise RuntimeError(status.ResolvedErrorMessage)
            else:
                raise RuntimeError("Veristand gateway already in use could not connect!!")

    def _get_aliases(self):
        """
        Gets alias information about the deployed system
        """
        aliases = {}
        alias_array = Array[String]([String("")])
        channel_array = Array[String]([String("")])
        status = self.factory_worker.GetAliasList(alias_array, channel_array)
        for number, alias in enumerate(status[1]):
            aliases[alias] = status[2][number]
        return aliases

    def status(self):
        if self.factory_worker is not None:
            self._getsystemstate()
            return self.system_status_state.name, self.name, self.system_status_sdf_location, self.target_status_state
        return System.Disconnected.name, '', {}

    def read_channel(self, alias_name=""):
        """
        Read the data of a defined Alias

        :param alias_name: Aliases name to read
        :type alias_name: str
        """
        value_ref = Double(0)
        if self.factory_worker is not None:
            self._getsystemstate()
            if self.system_status_state == System.Active:
                aliases = self._get_aliases()
                if alias_name in aliases.keys():
                    status = self.factory_worker.GetSingleChannelValue(alias_name, value_ref)
                    if status[0].IsError:
                        raise RuntimeError(status[0].ResolvedErrorMessage)
                    return status[1]
                else:
                    raise RuntimeError("Alias is not defined")
            else:
                raise RuntimeError("Cannot read when system is not active!!!")

    def disconnect(self):
        """
        Disconnect and un-deploy from the Veristand gateway
        """
        self._createfactoryworker()
        if self.factory_worker is not None:
            self._getsystemstate()
            if self.system_status_state == System.Active:
                status = self.factory_worker.DisconnectFromSystem("", True)
                if status.IsError:
                    raise RuntimeError(status.ResolvedErrorMessage)
            else:
                raise RuntimeError("Veristand gateway could not disconnect!!")

if __name__ == '__main__':
    import time
    # sdfdeploy = SystemDefinitionDeploy()
    #
    #
    # try:
    #     sdfdeploy.disconnect()
    # except RuntimeError as e:
    #     print(e)
    #
    #
    # print(sdfdeploy.status())
    # try:
    #     sdfdeploy.connect(name="real_Test_new_windows", file_path="C:\\Users\\J73670\\Desktop\\")
    # except RuntimeError as e:
    #     print(e)
    #     print(sdfdeploy.status())
    # print(sdfdeploy.status())
    # try:
    #     sdfdeploy.connect()
    # except RuntimeError as e:
    #     print(e)
    #     print(sdfdeploy.status())
    # time.sleep(2)
    # print(sdfdeploy.read_channel("Loop_Rate"))
    # print(sdfdeploy.read_channel("Absolute_Time"))
    # time.sleep(2)
    # print(sdfdeploy.read_channel("Loop_Rate"))
    # print(sdfdeploy.read_channel("Absolute_Time"))
    # time.sleep(2)
    # try:
    #     print(sdfdeploy.read_channel("Steaviethetv"))
    # except RuntimeError as e:
    #     print(e)
    # time.sleep(2)
    # print(sdfdeploy.read_channel("Loop_Rate"))
    # print(sdfdeploy.read_channel("Absolute_Time"))
    # print(sdfdeploy.status())
    # time.sleep(10)
    # try:
    #     sdfdeploy.disconnect()
    # except RuntimeError as e:
    #     print(e)
    # try:
    #     sdfdeploy.disconnect()
    # except RuntimeError as e:
    #     print(e)
    # print(sdfdeploy.status())

    # Tests done at Intech
    sdfdeploy = SystemDefinitionDeploy()
    try:
        sdfdeploy.disconnect()
    except RuntimeError as e:
        print(e)
    sdfdeploy.connect(name="test1",
                      file_path="C:\\Users\\Public\\Documents\\National Instruments\\NI VeriStand 2016\\Projects\\test1")
    time.sleep(5)
    sdfdeploy.disconnect()

